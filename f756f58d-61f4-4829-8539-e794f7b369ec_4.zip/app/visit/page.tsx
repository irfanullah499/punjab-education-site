'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';

export default function VisitUs() {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Fixed Transparent Navbar */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        scrollY > 100 ? 'bg-black/80 backdrop-blur-lg' : 'bg-transparent'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center">
                <i className="ri-graduation-cap-fill text-black text-xl"></i>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-yellow-400 font-serif">
                  New Punjab School
                </h1>
                <p className="text-sm text-yellow-300">& College</p>
              </div>
            </Link>
            <div className="hidden md:flex space-x-8">
              <Link href="/" className="text-white hover:text-yellow-400 font-medium transition-colors">Home</Link>
              <Link href="/story" className="text-white hover:text-yellow-400 font-medium transition-colors">Our Story</Link>
              <Link href="/menu" className="text-white hover:text-yellow-400 font-medium transition-colors">Menu</Link>
              <Link href="/gallery" className="text-white hover:text-yellow-400 font-medium transition-colors">Gallery</Link>
              <Link href="/visit" className="text-yellow-400 font-medium">Visit Us</Link>
              <Link href="/blog" className="text-white hover:text-yellow-400 font-medium transition-colors">Blog</Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center pt-20">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=elegant%20educational%20building%20exterior%20with%20warm%20golden%20lighting%20sophisticated%20architecture%20academic%20institution%20luxury%20school%20facade%20beautiful%20entrance%20with%20classical%20design&width=1920&height=1080&seq=visithero&orientation=landscape')`
          }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/40"></div>
        
        <div className="relative z-10 text-center max-w-4xl mx-auto px-4">
          <h1 className="text-6xl md:text-8xl font-serif font-bold mb-8 text-yellow-400">
            Visit Us
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-12 font-light leading-relaxed">
            Experience luxury education at our prestigious campus in the heart of Lahore
          </p>
        </div>
      </section>

      {/* Location & Contact Info */}
      <section className="py-20 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            
            {/* Contact Information */}
            <div className="space-y-8">
              <div>
                <h2 className="text-4xl md:text-5xl font-serif font-bold text-yellow-400 mb-8">
                  Get in Touch
                </h2>
                <p className="text-xl text-gray-300 leading-relaxed mb-8">
                  Visit our campus to experience the luxury learning environment that has made us Lahore's premier educational institution.
                </p>
              </div>

              <div className="space-y-6">
                <div className="bg-gradient-to-br from-yellow-900/20 to-black rounded-xl p-6 border border-yellow-800/30">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center mr-4">
                      <i className="ri-map-pin-fill text-black text-xl"></i>
                    </div>
                    <h3 className="text-xl font-semibold text-yellow-400">Our Location</h3>
                  </div>
                  <p className="text-gray-300 text-lg">
                    Cavalry Street 6<br />
                    Lahore, Punjab<br />
                    Pakistan
                  </p>
                </div>

                <div className="bg-gradient-to-br from-yellow-900/20 to-black rounded-xl p-6 border border-yellow-800/30">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center mr-4">
                      <i className="ri-phone-fill text-black text-xl"></i>
                    </div>
                    <h3 className="text-xl font-semibold text-yellow-400">Phone</h3>
                  </div>
                  <p className="text-gray-300 text-lg">03010600547</p>
                  <p className="text-gray-400 text-sm mt-2">Available 24/7 for inquiries</p>
                </div>

                <div className="bg-gradient-to-br from-yellow-900/20 to-black rounded-xl p-6 border border-yellow-800/30">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center mr-4">
                      <i className="ri-time-fill text-black text-xl"></i>
                    </div>
                    <h3 className="text-xl font-semibold text-yellow-400">Operating Hours</h3>
                  </div>
                  <div className="text-gray-300 space-y-2">
                    <p>Monday - Saturday: 8:00 AM - 10:00 PM</p>
                    <p>Sunday: 10:00 AM - 6:00 PM</p>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-yellow-900/20 to-black rounded-xl p-6 border border-yellow-800/30">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center mr-4">
                      <i className="ri-mail-fill text-black text-xl"></i>
                    </div>
                    <h3 className="text-xl font-semibold text-yellow-400">Email</h3>
                  </div>
                  <p className="text-gray-300 text-lg">info@newpunjabschool.com</p>
                  <p className="text-gray-400 text-sm mt-2">We respond within 24 hours</p>
                </div>
              </div>
            </div>

            {/* Map */}
            <div className="lg:pl-8">
              <h3 className="text-2xl font-serif font-bold text-yellow-400 mb-6">Find Us on Map</h3>
              <div className="bg-gradient-to-br from-yellow-900/20 to-black rounded-xl p-4 border border-yellow-800/30 h-96">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3402.1234567890123!2d74.35973!3d31.5204!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzHCsDMxJzEzLjQiTiA3NMKwMjEnMzUuMCJF!5e0!3m2!1sen!2spk!4v1234567890123!5m2!1sen!2spk"
                  width="100%"
                  height="100%"
                  style={{ border: 0, borderRadius: '8px' }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="New Punjab School & College Location"
                ></iframe>
              </div>
              <p className="text-gray-400 text-sm mt-4 text-center">
                Located in the prestigious Cavalry Ground area of Lahore
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Campus Features */}
      <section className="py-20 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-yellow-400 mb-6">
              Campus Features
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Discover what makes our campus the perfect environment for luxury learning
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-yellow-900/20 to-black rounded-xl p-8 border border-yellow-800/30 hover:border-yellow-600/50 transition-all duration-300 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-home-4-fill text-black text-2xl"></i>
              </div>
              <h3 className="text-xl font-serif font-bold text-yellow-400 mb-4">Luxury Classrooms</h3>
              <p className="text-gray-300 leading-relaxed">
                State-of-the-art classrooms designed for comfort and optimal learning with modern amenities
              </p>
            </div>

            <div className="bg-gradient-to-br from-yellow-900/20 to-black rounded-xl p-8 border border-yellow-800/30 hover:border-yellow-600/50 transition-all duration-300 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-book-fill text-black text-2xl"></i>
              </div>
              <h3 className="text-xl font-serif font-bold text-yellow-400 mb-4">Premium Library</h3>
              <p className="text-gray-300 leading-relaxed">
                Extensive collection of books and digital resources in an elegant, quiet study environment
              </p>
            </div>

            <div className="bg-gradient-to-br from-yellow-900/20 to-black rounded-xl p-8 border border-yellow-800/30 hover:border-yellow-600/50 transition-all duration-300 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-computer-fill text-black text-2xl"></i>
              </div>
              <h3 className="text-xl font-serif font-bold text-yellow-400 mb-4">Tech Lab</h3>
              <p className="text-gray-300 leading-relaxed">
                Modern computer lab with latest technology for digital learning and research
              </p>
            </div>

            <div className="bg-gradient-to-br from-yellow-900/20 to-black rounded-xl p-8 border border-yellow-800/30 hover:border-yellow-600/50 transition-all duration-300 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-flask-fill text-black text-2xl"></i>
              </div>
              <h3 className="text-xl font-serif font-bold text-yellow-400 mb-4">Science Labs</h3>
              <p className="text-gray-300 leading-relaxed">
                Fully equipped laboratories for physics, chemistry, and biology practical work
              </p>
            </div>

            <div className="bg-gradient-to-br from-yellow-900/20 to-black rounded-xl p-8 border border-yellow-800/30 hover:border-yellow-600/50 transition-all duration-300 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-cup-fill text-black text-2xl"></i>
              </div>
              <h3 className="text-xl font-serif font-bold text-yellow-400 mb-4">Café Lounge</h3>
              <p className="text-gray-300 leading-relaxed">
                Elegant café space for relaxation and informal study sessions with premium refreshments
              </p>
            </div>

            <div className="bg-gradient-to-br from-yellow-900/20 to-black rounded-xl p-8 border border-yellow-800/30 hover:border-yellow-600/50 transition-all duration-300 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-car-fill text-black text-2xl"></i>
              </div>
              <h3 className="text-xl font-serif font-bold text-yellow-400 mb-4">Parking</h3>
              <p className="text-gray-300 leading-relaxed">
                Secure and convenient parking facilities for students and visitors
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Directions */}
      <section className="py-20 bg-gray-900">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-yellow-400 mb-8">
            How to Reach Us
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-gradient-to-br from-yellow-900/20 to-black rounded-xl p-8 border border-yellow-800/30">
              <div className="w-16 h-16 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-car-fill text-black text-2xl"></i>
              </div>
              <h3 className="text-xl font-serif font-bold text-yellow-400 mb-4">By Car</h3>
              <p className="text-gray-300 leading-relaxed">
                Take Main Boulevard and turn towards Cavalry Ground. Our campus is easily accessible with dedicated parking available.
              </p>
            </div>
            
            <div className="bg-gradient-to-br from-yellow-900/20 to-black rounded-xl p-8 border border-yellow-800/30">
              <div className="w-16 h-16 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-bus-fill text-black text-2xl"></i>
              </div>
              <h3 className="text-xl font-serif font-bold text-yellow-400 mb-4">Public Transport</h3>
              <p className="text-gray-300 leading-relaxed">
                Multiple bus routes serve the Cavalry area. The nearest bus stop is just a 5-minute walk from our campus.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-yellow-900/20 to-black">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-yellow-400 mb-6">
            Ready to Visit?
          </h2>
          <p className="text-xl text-gray-300 mb-12 leading-relaxed">
            Schedule a campus tour and experience the luxury learning environment firsthand
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <a 
              href={`https://wa.me/923010600547?text=${encodeURIComponent('Hi! I would like to schedule a campus tour at New Punjab School & College. Please let me know available times.')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-gradient-to-r from-yellow-600 to-yellow-400 text-black px-8 py-4 rounded-full font-semibold text-lg hover:from-yellow-500 hover:to-yellow-300 transition-all duration-300 cursor-pointer whitespace-nowrap flex items-center justify-center"
            >
              <i className="ri-whatsapp-fill mr-2 text-xl"></i>
              Schedule a Tour
            </a>
            <Link 
              href="/menu"
              className="border-2 border-yellow-400 text-yellow-400 hover:bg-yellow-400 hover:text-black px-8 py-4 rounded-full font-semibold text-lg transition-all duration-300 cursor-pointer whitespace-nowrap"
            >
              View Our Services
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16 border-t border-yellow-800/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center">
                  <i className="ri-graduation-cap-fill text-black text-lg"></i>
                </div>
                <div>
                  <h3 className="text-xl font-bold font-serif text-yellow-400">New Punjab School</h3>
                  <p className="text-sm text-yellow-300">& College</p>
                </div>
              </div>
              <p className="text-gray-400 leading-relaxed">
                Luxury education services where academic excellence meets sophisticated learning experiences.
              </p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4 text-yellow-400">Quick Links</h4>
              <ul className="space-y-2">
                <li><Link href="/" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Home</Link></li>
                <li><Link href="/story" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Our Story</Link></li>
                <li><Link href="/menu" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Menu</Link></li>
                <li><Link href="/gallery" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Gallery</Link></li>
                <li><Link href="/blog" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Blog</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4 text-yellow-400">Education Levels</h4>
              <ul className="space-y-2">
                <li className="text-gray-400">Matric Excellence</li>
                <li className="text-gray-400">F.Sc Mastery</li>
                <li className="text-gray-400">I.Com Premium</li>
                <li className="text-gray-400">B.Com & B.Sc Elite</li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4 text-yellow-400">Contact</h4>
              <div className="space-y-3">
                <p className="text-gray-400 flex items-center">
                  <i className="ri-phone-fill mr-3 text-yellow-400"></i>
                  03010600547
                </p>
                <p className="text-gray-400 flex items-center">
                  <i className="ri-map-pin-fill mr-3 text-yellow-400"></i>
                  Cavalry Street 6, Lahore
                </p>
                <p className="text-gray-400 flex items-center">
                  <i className="ri-time-fill mr-3 text-yellow-400"></i>
                  Mon-Sat: 8AM-10PM
                </p>
              </div>
            </div>
          </div>
          
          <div className="border-t border-yellow-800/20 mt-12 pt-8 text-center">
            <p className="text-gray-400">
              © 2024 New Punjab School & College. Where futures begin.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}