'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';

export default function OurStory() {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const timelineEvents = [
    {
      year: "2019",
      title: "The Dream Begins",
      description: "Founded with a vision to revolutionize home tuition in Lahore, combining academic excellence with luxury learning experiences.",
      image: "https://readdy.ai/api/search-image?query=vintage%20educational%20founding%20moment%20with%20books%20scrolls%20warm%20golden%20lighting%20elegant%20wooden%20desk%20academic%20atmosphere%20historical%20beginning%20luxury%20education%20setting&width=600&height=400&seq=story1&orientation=landscape"
    },
    {
      year: "2020",
      title: "Building Excellence",
      description: "Assembled a team of elite educators and developed our signature personalized learning methodology that would set new standards.",
      image: "https://readdy.ai/api/search-image?query=professional%20educators%20team%20meeting%20around%20elegant%20wooden%20table%20with%20books%20academic%20materials%20warm%20golden%20lighting%20luxury%20educational%20setting%20sophisticated%20atmosphere&width=600&height=400&seq=story2&orientation=landscape"
    },
    {
      year: "2021",
      title: "First Success Stories",
      description: "Our students began achieving remarkable results, with 95% securing admission to top universities across Pakistan.",
      image: "https://readdy.ai/api/search-image?query=graduation%20celebration%20students%20in%20academic%20robes%20holding%20certificates%20warm%20golden%20lighting%20proud%20moment%20luxury%20educational%20achievement%20elegant%20setting&width=600&height=400&seq=story3&orientation=landscape"
    },
    {
      year: "2022",
      title: "Innovation in Learning",
      description: "Introduced cutting-edge teaching methodologies and personalized learning paths tailored to each student's unique potential.",
      image: "https://readdy.ai/api/search-image?query=modern%20innovative%20classroom%20with%20advanced%20teaching%20materials%20interactive%20learning%20environment%20warm%20golden%20lighting%20luxury%20educational%20technology%20sophisticated%20academic%20setting&width=600&height=400&seq=story4&orientation=landscape"
    },
    {
      year: "2023",
      title: "Community Impact",
      description: "Expanded our reach to serve over 500 students across Lahore, becoming the premier choice for luxury home tuition services.",
      image: "https://readdy.ai/api/search-image?query=diverse%20group%20of%20students%20studying%20together%20books%20notebooks%20academic%20materials%20warm%20golden%20lighting%20community%20learning%20environment%20luxury%20educational%20setting&width=600&height=400&seq=story5&orientation=landscape"
    },
    {
      year: "2024",
      title: "The Future Continues",
      description: "Today, we continue to innovate and inspire, helping students step confidently into their bright futures.",
      image: "https://readdy.ai/api/search-image?query=bright%20future%20vision%20students%20walking%20towards%20golden%20light%20academic%20success%20pathway%20luxury%20educational%20journey%20hope%20and%20achievement%20sophisticated%20setting&width=600&height=400&seq=story6&orientation=landscape"
    }
  ];

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Fixed Transparent Navbar */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        scrollY > 100 ? 'bg-black/80 backdrop-blur-lg' : 'bg-transparent'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center">
                <i className="ri-graduation-cap-fill text-black text-xl"></i>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-yellow-400 font-serif">
                  New Punjab School
                </h1>
                <p className="text-sm text-yellow-300">& College</p>
              </div>
            </Link>
            <div className="hidden md:flex space-x-8">
              <Link href="/" className="text-white hover:text-yellow-400 font-medium transition-colors">Home</Link>
              <Link href="/story" className="text-yellow-400 font-medium">Our Story</Link>
              <Link href="/menu" className="text-white hover:text-yellow-400 font-medium transition-colors">Menu</Link>
              <Link href="/gallery" className="text-white hover:text-yellow-400 font-medium transition-colors">Gallery</Link>
              <Link href="/visit" className="text-white hover:text-yellow-400 font-medium transition-colors">Visit Us</Link>
              <Link href="/blog" className="text-white hover:text-yellow-400 font-medium transition-colors">Blog</Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center pt-20">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=elegant%20vintage%20library%20with%20ancient%20books%20leather%20bound%20volumes%20warm%20golden%20candlelight%20sophisticated%20academic%20atmosphere%20luxury%20educational%20heritage%20classic%20scholarly%20setting&width=1920&height=1080&seq=storyhero&orientation=landscape')`
          }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/40"></div>
        
        <div className="relative z-10 text-center max-w-4xl mx-auto px-4">
          <h1 className="text-6xl md:text-8xl font-serif font-bold mb-8 text-yellow-400">
            Our Story
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-12 font-light leading-relaxed">
            A journey of excellence, innovation, and dreams fulfilled
          </p>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="py-20 bg-gradient-to-b from-black to-gray-900">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-yellow-400 mb-6">
              Journey Through Time
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Discover how we've grown from a small vision to Lahore's premier luxury education service
            </p>
          </div>

          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-yellow-600 to-yellow-400"></div>

            {timelineEvents.map((event, index) => (
              <div key={index} className={`relative mb-16 ${index % 2 === 0 ? 'text-right pr-8' : 'text-left pl-8'}`}>
                {/* Timeline Dot */}
                <div className="absolute top-8 left-1/2 transform -translate-x-1/2 w-6 h-6 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full border-4 border-black z-10"></div>
                
                <div className={`flex items-center gap-8 ${index % 2 === 0 ? 'flex-row-reverse' : 'flex-row'}`}>
                  {/* Content */}
                  <div className="flex-1">
                    <div className="bg-gradient-to-br from-yellow-900/20 to-black rounded-xl p-8 border border-yellow-800/30 hover:border-yellow-600/50 transition-all duration-300">
                      <div className="text-3xl font-bold text-yellow-400 font-serif mb-2">{event.year}</div>
                      <h3 className="text-2xl font-serif font-bold text-white mb-4">{event.title}</h3>
                      <p className="text-gray-300 leading-relaxed">{event.description}</p>
                    </div>
                  </div>
                  
                  {/* Image */}
                  <div className="flex-1">
                    <div className="rounded-xl overflow-hidden shadow-2xl">
                      <img 
                        src={event.image} 
                        alt={event.title}
                        className="w-full h-64 object-cover hover:scale-110 transition-transform duration-300"
                      />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            <div className="bg-gradient-to-br from-yellow-900/20 to-black rounded-xl p-12 border border-yellow-800/30">
              <div className="w-16 h-16 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center mb-8">
                <i className="ri-eye-fill text-black text-2xl"></i>
              </div>
              <h3 className="text-3xl font-serif font-bold text-yellow-400 mb-6">Our Vision</h3>
              <p className="text-gray-300 text-lg leading-relaxed">
                To be the premier luxury education service in Pakistan, where every student experiences personalized excellence and steps confidently into their bright future. We envision a world where quality education is accessible, engaging, and transformative.
              </p>
            </div>
            
            <div className="bg-gradient-to-br from-yellow-900/20 to-black rounded-xl p-12 border border-yellow-800/30">
              <div className="w-16 h-16 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center mb-8">
                <i className="ri-target-fill text-black text-2xl"></i>
              </div>
              <h3 className="text-3xl font-serif font-bold text-yellow-400 mb-6">Our Mission</h3>
              <p className="text-gray-300 text-lg leading-relaxed">
                To provide exceptional home tuition services that combine academic rigor with luxury learning experiences. We are committed to nurturing each student's unique potential through personalized attention, innovative teaching methods, and unwavering support.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-yellow-400 mb-6">
              Our Core Values
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              The principles that guide every interaction and shape every learning experience
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center group">
              <div className="w-20 h-20 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                <i className="ri-star-fill text-black text-2xl"></i>
              </div>
              <h4 className="text-xl font-serif font-bold text-yellow-400 mb-4">Excellence</h4>
              <p className="text-gray-300 leading-relaxed">
                We strive for nothing less than exceptional results in every aspect of education
              </p>
            </div>
            
            <div className="text-center group">
              <div className="w-20 h-20 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                <i className="ri-heart-fill text-black text-2xl"></i>
              </div>
              <h4 className="text-xl font-serif font-bold text-yellow-400 mb-4">Care</h4>
              <p className="text-gray-300 leading-relaxed">
                Every student receives personalized attention and genuine care for their academic journey
              </p>
            </div>
            
            <div className="text-center group">
              <div className="w-20 h-20 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                <i className="ri-lightbulb-fill text-black text-2xl"></i>
              </div>
              <h4 className="text-xl font-serif font-bold text-yellow-400 mb-4">Innovation</h4>
              <p className="text-gray-300 leading-relaxed">
                We continuously evolve our teaching methods to meet modern learning needs
              </p>
            </div>
            
            <div className="text-center group">
              <div className="w-20 h-20 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                <i className="ri-shield-check-fill text-black text-2xl"></i>
              </div>
              <h4 className="text-xl font-serif font-bold text-yellow-400 mb-4">Integrity</h4>
              <p className="text-gray-300 leading-relaxed">
                Honest communication and ethical practices form the foundation of our relationships
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-yellow-900/20 to-black">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-yellow-400 mb-6">
            Ready to Begin Your Story?
          </h2>
          <p className="text-xl text-gray-300 mb-12 leading-relaxed">
            Join the hundreds of students who have already stepped into their bright futures with us
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Link 
              href="/menu"
              className="bg-gradient-to-r from-yellow-600 to-yellow-400 text-black px-8 py-4 rounded-full font-semibold text-lg hover:from-yellow-500 hover:to-yellow-300 transition-all duration-300 cursor-pointer whitespace-nowrap"
            >
              Explore Our Services
            </Link>
            <Link 
              href="/visit"
              className="border-2 border-yellow-400 text-yellow-400 hover:bg-yellow-400 hover:text-black px-8 py-4 rounded-full font-semibold text-lg transition-all duration-300 cursor-pointer whitespace-nowrap"
            >
              Visit Our Campus
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16 border-t border-yellow-800/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center">
                  <i className="ri-graduation-cap-fill text-black text-lg"></i>
                </div>
                <div>
                  <h3 className="text-xl font-bold font-serif text-yellow-400">New Punjab School</h3>
                  <p className="text-sm text-yellow-300">& College</p>
                </div>
              </div>
              <p className="text-gray-400 leading-relaxed">
                Luxury education services where academic excellence meets sophisticated learning experiences.
              </p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4 text-yellow-400">Quick Links</h4>
              <ul className="space-y-2">
                <li><Link href="/" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Home</Link></li>
                <li><Link href="/menu" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Services Menu</Link></li>
                <li><Link href="/gallery" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Gallery</Link></li>
                <li><Link href="/blog" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Blog</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4 text-yellow-400">Education Levels</h4>
              <ul className="space-y-2">
                <li className="text-gray-400">Matric Excellence</li>
                <li className="text-gray-400">F.Sc Mastery</li>
                <li className="text-gray-400">I.Com Premium</li>
                <li className="text-gray-400">B.Com & B.Sc Elite</li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4 text-yellow-400">Contact</h4>
              <div className="space-y-3">
                <p className="text-gray-400 flex items-center">
                  <i className="ri-phone-fill mr-3 text-yellow-400"></i>
                  03010600547
                </p>
                <p className="text-gray-400 flex items-center">
                  <i className="ri-map-pin-fill mr-3 text-yellow-400"></i>
                  Cavalry Street 6, Lahore
                </p>
                <p className="text-gray-400 flex items-center">
                  <i className="ri-time-fill mr-3 text-yellow-400"></i>
                  Mon-Sat: 8AM-10PM
                </p>
              </div>
            </div>
          </div>
          
          <div className="border-t border-yellow-800/20 mt-12 pt-8 text-center">
            <p className="text-gray-400">
              © 2024 New Punjab School & College. Where futures begin.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}