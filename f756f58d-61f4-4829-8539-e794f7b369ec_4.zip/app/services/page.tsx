'use client';

import Link from 'next/link';

export default function Services() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center">
                <i className="ri-graduation-cap-fill text-white text-xl"></i>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-blue-900" style={{fontFamily: 'Pacifico, serif'}}>
                  New Punjab School
                </h1>
                <p className="text-sm text-blue-600">& College</p>
              </div>
            </Link>
            <nav className="hidden md:flex space-x-8">
              <Link href="/" className="text-blue-900 hover:text-blue-600 font-medium">Home</Link>
              <Link href="/services" className="text-blue-600 font-medium">Services</Link>
              <Link href="/tutors" className="text-blue-900 hover:text-blue-600 font-medium">Tutors</Link>
              <Link href="/about" className="text-blue-900 hover:text-blue-600 font-medium">About</Link>
              <Link href="/contact" className="text-blue-900 hover:text-blue-600 font-medium">Contact</Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-900 to-blue-600 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold text-white mb-6">Our Services</h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            Comprehensive home tuition services designed to help students achieve academic excellence
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            
            {/* Individual Tuition */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="h-64 bg-cover bg-center"
                style={{
                  backgroundImage: `url('https://readdy.ai/api/search-image?query=one%20on%20one%20tutoring%20session%20with%20teacher%20and%20student%20at%20home%20books%20and%20notebooks%20on%20table%20bright%20natural%20lighting%20professional%20educational%20setting%20clean%20modern%20interior&width=600&height=400&seq=service1&orientation=landscape')`
                }}
              ></div>
              <div className="p-8">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                    <i className="ri-user-fill text-blue-600 text-xl"></i>
                  </div>
                  <h3 className="text-2xl font-bold text-blue-900">Individual Home Tuition</h3>
                </div>
                <p className="text-gray-600 mb-6">
                  Personalized one-on-one tutoring sessions at your home with dedicated attention to each student's unique learning needs and pace.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center text-gray-700">
                    <i className="ri-check-line text-green-600 mr-2"></i>
                    Customized learning plans
                  </li>
                  <li className="flex items-center text-gray-700">
                    <i className="ri-check-line text-green-600 mr-2"></i>
                    Flexible scheduling
                  </li>
                  <li className="flex items-center text-gray-700">
                    <i className="ri-check-line text-green-600 mr-2"></i>
                    Progress tracking
                  </li>
                  <li className="flex items-center text-gray-700">
                    <i className="ri-check-line text-green-600 mr-2"></i>
                    Regular assessments
                  </li>
                </ul>
                <div className="text-2xl font-bold text-blue-900 mb-4">Starting from Rs. 15,000/month</div>
              </div>
            </div>

            {/* Group Tuition */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="h-64 bg-cover bg-center"
                style={{
                  backgroundImage: `url('https://readdy.ai/api/search-image?query=small%20group%20of%20students%20studying%20together%20with%20teacher%20at%20home%20educational%20materials%20books%20notebooks%20collaborative%20learning%20environment%20bright%20clean%20setting&width=600&height=400&seq=service2&orientation=landscape')`
                }}
              ></div>
              <div className="p-8">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mr-4">
                    <i className="ri-group-fill text-yellow-600 text-xl"></i>
                  </div>
                  <h3 className="text-2xl font-bold text-blue-900">Small Group Tuition</h3>
                </div>
                <p className="text-gray-600 mb-6">
                  Interactive group sessions with 2-4 students, promoting collaborative learning while maintaining personalized attention.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center text-gray-700">
                    <i className="ri-check-line text-green-600 mr-2"></i>
                    Interactive discussions
                  </li>
                  <li className="flex items-center text-gray-700">
                    <i className="ri-check-line text-green-600 mr-2"></i>
                    Peer learning opportunities
                  </li>
                  <li className="flex items-center text-gray-700">
                    <i className="ri-check-line text-green-600 mr-2"></i>
                    Cost-effective option
                  </li>
                  <li className="flex items-center text-gray-700">
                    <i className="ri-check-line text-green-600 mr-2"></i>
                    Competitive environment
                  </li>
                </ul>
                <div className="text-2xl font-bold text-blue-900 mb-4">Starting from Rs. 8,000/month</div>
              </div>
            </div>

            {/* Online Tuition */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="h-64 bg-cover bg-center"
                style={{
                  backgroundImage: `url('https://readdy.ai/api/search-image?query=online%20learning%20setup%20with%20computer%20screen%20showing%20virtual%20classroom%20student%20at%20desk%20with%20books%20modern%20technology%20education%20bright%20clean%20workspace%20professional%20setting&width=600&height=400&seq=service3&orientation=landscape')`
                }}
              ></div>
              <div className="p-8">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mr-4">
                    <i className="ri-computer-fill text-green-600 text-xl"></i>
                  </div>
                  <h3 className="text-2xl font-bold text-blue-900">Online Tuition</h3>
                </div>
                <p className="text-gray-600 mb-6">
                  Convenient online tutoring sessions using modern technology and interactive tools for effective remote learning.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center text-gray-700">
                    <i className="ri-check-line text-green-600 mr-2"></i>
                    Interactive whiteboards
                  </li>
                  <li className="flex items-center text-gray-700">
                    <i className="ri-check-line text-green-600 mr-2"></i>
                    Recorded sessions
                  </li>
                  <li className="flex items-center text-gray-700">
                    <i className="ri-check-line text-green-600 mr-2"></i>
                    Digital resources
                  </li>
                  <li className="flex items-center text-gray-700">
                    <i className="ri-check-line text-green-600 mr-2"></i>
                    Flexible timing
                  </li>
                </ul>
                <div className="text-2xl font-bold text-blue-900 mb-4">Starting from Rs. 12,000/month</div>
              </div>
            </div>

            {/* Exam Preparation */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="h-64 bg-cover bg-center"
                style={{
                  backgroundImage: `url('https://readdy.ai/api/search-image?query=exam%20preparation%20session%20with%20student%20and%20teacher%20practice%20papers%20textbooks%20calculator%20focused%20study%20environment%20educational%20materials%20bright%20clean%20workspace&width=600&height=400&seq=service4&orientation=landscape')`
                }}
              ></div>
              <div className="p-8">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mr-4">
                    <i className="ri-file-text-fill text-purple-600 text-xl"></i>
                  </div>
                  <h3 className="text-2xl font-bold text-blue-900">Exam Preparation</h3>
                </div>
                <p className="text-gray-600 mb-6">
                  Intensive exam preparation sessions with mock tests, practice papers, and strategic guidance for optimal performance.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center text-gray-700">
                    <i className="ri-check-line text-green-600 mr-2"></i>
                    Mock examinations
                  </li>
                  <li className="flex items-center text-gray-700">
                    <i className="ri-check-line text-green-600 mr-2"></i>
                    Past papers practice
                  </li>
                  <li className="flex items-center text-gray-700">
                    <i className="ri-check-line text-green-600 mr-2"></i>
                    Time management strategies
                  </li>
                  <li className="flex items-center text-gray-700">
                    <i className="ri-check-line text-green-600 mr-2"></i>
                    Subject-specific guidance
                  </li>
                </ul>
                <div className="text-2xl font-bold text-blue-900 mb-4">Starting from Rs. 18,000/month</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* School Systems */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-blue-900 mb-4">School Systems We Support</h2>
            <p className="text-xl text-gray-600">
              We provide tuition for students from all major school systems in Pakistan
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white rounded-lg p-6 text-center shadow-md hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-school-fill text-blue-600 text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-blue-900 mb-2">Beaconhouse</h3>
              <p className="text-gray-600 text-sm">Complete curriculum support for Beaconhouse students</p>
            </div>
            
            <div className="bg-white rounded-lg p-6 text-center shadow-md hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-book-open-fill text-yellow-600 text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-blue-900 mb-2">Unique School</h3>
              <p className="text-gray-600 text-sm">Specialized teaching methods for Unique School curriculum</p>
            </div>
            
            <div className="bg-white rounded-lg p-6 text-center shadow-md hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-trophy-fill text-green-600 text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-blue-900 mb-2">Allied School</h3>
              <p className="text-gray-600 text-sm">Expert guidance for Allied School system students</p>
            </div>
            
            <div className="bg-white rounded-lg p-6 text-center shadow-md hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-graduation-cap-fill text-purple-600 text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-blue-900 mb-2">Government Schools</h3>
              <p className="text-gray-600 text-sm">Support for government school curricula and boards</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-900 to-blue-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">Ready to Get Started?</h2>
          <p className="text-xl text-blue-100 mb-8">
            Choose the perfect tuition service for your academic needs and start your journey to success
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact" className="bg-yellow-500 hover:bg-yellow-400 text-blue-900 px-8 py-4 rounded-lg font-semibold text-lg transition-colors whitespace-nowrap cursor-pointer">
              Book a Session
            </Link>
            <Link href="/tutors" className="border-2 border-white text-white hover:bg-white hover:text-blue-900 px-8 py-4 rounded-lg font-semibold text-lg transition-colors whitespace-nowrap cursor-pointer">
              Meet Our Tutors
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-blue-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-yellow-500 rounded-full flex items-center justify-center">
                  <i className="ri-graduation-cap-fill text-blue-900 text-lg"></i>
                </div>
                <div>
                  <h3 className="text-xl font-bold" style={{fontFamily: 'Pacifico, serif'}}>New Punjab School</h3>
                  <p className="text-sm text-blue-300">& College</p>
                </div>
              </div>
              <p className="text-blue-300">
                Providing quality home tuition services with qualified tutors for academic excellence.
              </p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li><Link href="/services" className="text-blue-300 hover:text-white cursor-pointer">Services</Link></li>
                <li><Link href="/tutors" className="text-blue-300 hover:text-white cursor-pointer">Tutors</Link></li>
                <li><Link href="/about" className="text-blue-300 hover:text-white cursor-pointer">About Us</Link></li>
                <li><Link href="/contact" className="text-blue-300 hover:text-white cursor-pointer">Contact</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Subjects</h4>
              <ul className="space-y-2">
                <li className="text-blue-300">Matric</li>
                <li className="text-blue-300">F.Sc</li>
                <li className="text-blue-300">I.Com</li>
                <li className="text-blue-300">B.Com & B.Sc</li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Contact Info</h4>
              <div className="space-y-2">
                <p className="text-blue-300 flex items-center">
                  <i className="ri-phone-fill mr-2"></i>
                  03010600547
                </p>
                <p className="text-blue-300 flex items-center">
                  <i className="ri-mail-fill mr-2"></i>
                  info@newpunjabschool.com
                </p>
                <p className="text-blue-300 flex items-center">
                  <i className="ri-map-pin-fill mr-2"></i>
                  Lahore, Punjab, Pakistan
                </p>
              </div>
            </div>
          </div>
          
          <div className="border-t border-blue-800 mt-8 pt-8 text-center">
            <p className="text-blue-300">
              © 2024 New Punjab School & College. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}