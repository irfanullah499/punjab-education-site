'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';

export default function Blog() {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const blogPosts = [
    {
      id: 1,
      title: "Mastering Mathematics: 10 Essential Tips for F.Sc Students",
      excerpt: "Discover proven strategies to excel in mathematics and build a strong foundation for engineering and medical entrance exams.",
      category: "Study Tips",
      date: "December 15, 2024",
      readTime: "5 min read",
      image: "https://readdy.ai/api/search-image?query=mathematics%20tutoring%20session%20with%20equations%20formulas%20on%20blackboard%20luxury%20educational%20setting%20warm%20golden%20lighting%20academic%20excellence%20sophisticated%20atmosphere&width=600&height=400&seq=blog1&orientation=landscape",
      author: "Dr. Ahmed Hassan"
    },
    {
      id: 2,
      title: "Success Story: From Average to Outstanding - Sarah's Journey",
      excerpt: "How personalized tutoring helped Sarah achieve 95% in her I.Com exams and secure admission to her dream university.",
      category: "Student Stories",
      date: "December 12, 2024",
      readTime: "3 min read",
      image: "https://readdy.ai/api/search-image?query=successful%20female%20student%20celebrating%20with%20books%20and%20certificates%20luxury%20educational%20achievement%20warm%20golden%20lighting%20academic%20success%20sophisticated%20setting&width=600&height=400&seq=blog2&orientation=landscape",
      author: "Sarah Fatima"
    },
    {
      id: 3,
      title: "The Art of Effective Home Tutoring: A Guide for Parents",
      excerpt: "Essential tips for parents to create an optimal learning environment and support their child's academic journey.",
      category: "Tutoring Guides",
      date: "December 10, 2024",
      readTime: "7 min read",
      image: "https://readdy.ai/api/search-image?query=parent%20and%20child%20studying%20together%20at%20home%20with%20tutor%20luxury%20educational%20environment%20warm%20golden%20lighting%20family%20learning%20sophisticated%20atmosphere&width=600&height=400&seq=blog3&orientation=landscape",
      author: "Prof. Maria Khan"
    },
    {
      id: 4,
      title: "Chemistry Made Easy: Laboratory Techniques for B.Sc Students",
      excerpt: "Master essential lab techniques and safety protocols that will set you apart in your chemistry studies.",
      category: "Study Tips",
      date: "December 8, 2024",
      readTime: "6 min read",
      image: "https://readdy.ai/api/search-image?query=chemistry%20laboratory%20with%20equipment%20beakers%20and%20scientific%20instruments%20luxury%20educational%20facility%20warm%20golden%20lighting%20academic%20research%20sophisticated%20setting&width=600&height=400&seq=blog4&orientation=landscape",
      author: "Dr. Raza Ali"
    },
    {
      id: 5,
      title: "Muhammad's Medical Dream: From Struggle to Success",
      excerpt: "A inspiring story of determination and how personalized tutoring helped Muhammad achieve his medical college dreams.",
      category: "Student Stories",
      date: "December 5, 2024",
      readTime: "4 min read",
      image: "https://readdy.ai/api/search-image?query=medical%20student%20with%20stethoscope%20and%20textbooks%20luxury%20educational%20achievement%20warm%20golden%20lighting%20healthcare%20education%20sophisticated%20academic%20setting&width=600&height=400&seq=blog5&orientation=landscape",
      author: "Muhammad Raza"
    },
    {
      id: 6,
      title: "Creating the Perfect Study Environment at Home",
      excerpt: "Transform your home into a luxury learning space that promotes focus, creativity, and academic excellence.",
      category: "Tutoring Guides",
      date: "December 3, 2024",
      readTime: "5 min read",
      image: "https://readdy.ai/api/search-image?query=elegant%20home%20study%20room%20with%20books%20desk%20lamp%20and%20educational%20materials%20luxury%20learning%20environment%20warm%20golden%20lighting%20sophisticated%20academic%20atmosphere&width=600&height=400&seq=blog6&orientation=landscape",
      author: "Interior Design Team"
    },
    {
      id: 7,
      title: "Physics Fundamentals: Building Strong Conceptual Understanding",
      excerpt: "Master the core concepts of physics with practical examples and real-world applications.",
      category: "Study Tips",
      date: "November 30, 2024",
      readTime: "8 min read",
      image: "https://readdy.ai/api/search-image?query=physics%20laboratory%20with%20scientific%20equipment%20and%20formulas%20on%20board%20luxury%20educational%20setting%20warm%20golden%20lighting%20academic%20research%20sophisticated%20atmosphere&width=600&height=400&seq=blog7&orientation=landscape",
      author: "Dr. Farah Ahmed"
    },
    {
      id: 8,
      title: "Aisha's Commerce Success: From Confusion to Clarity",
      excerpt: "How specialized commerce tutoring helped Aisha excel in accounting and business studies.",
      category: "Student Stories",
      date: "November 28, 2024",
      readTime: "3 min read",
      image: "https://readdy.ai/api/search-image?query=female%20student%20with%20business%20books%20and%20calculator%20successful%20commerce%20education%20luxury%20learning%20environment%20warm%20golden%20lighting%20academic%20achievement&width=600&height=400&seq=blog8&orientation=landscape",
      author: "Aisha Malik"
    },
    {
      id: 9,
      title: "Exam Preparation Strategies That Actually Work",
      excerpt: "Proven techniques for effective exam preparation, time management, and stress reduction during board exams.",
      category: "Tutoring Guides",
      date: "November 25, 2024",
      readTime: "6 min read",
      image: "https://readdy.ai/api/search-image?query=exam%20preparation%20with%20practice%20papers%20and%20study%20materials%20luxury%20educational%20environment%20warm%20golden%20lighting%20focused%20academic%20atmosphere%20sophisticated%20setting&width=600&height=400&seq=blog9&orientation=landscape",
      author: "Exam Preparation Team"
    }
  ];

  const categories = ['All', 'Study Tips', 'Student Stories', 'Tutoring Guides'];
  const [activeCategory, setActiveCategory] = useState('All');

  const filteredPosts = activeCategory === 'All' 
    ? blogPosts 
    : blogPosts.filter(post => post.category === activeCategory);

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Fixed Transparent Navbar */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        scrollY > 100 ? 'bg-black/80 backdrop-blur-lg' : 'bg-transparent'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center">
                <i className="ri-graduation-cap-fill text-black text-xl"></i>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-yellow-400 font-serif">
                  New Punjab School
                </h1>
                <p className="text-sm text-yellow-300">& College</p>
              </div>
            </Link>
            <div className="hidden md:flex space-x-8">
              <Link href="/" className="text-white hover:text-yellow-400 font-medium transition-colors">Home</Link>
              <Link href="/story" className="text-white hover:text-yellow-400 font-medium transition-colors">Our Story</Link>
              <Link href="/menu" className="text-white hover:text-yellow-400 font-medium transition-colors">Menu</Link>
              <Link href="/gallery" className="text-white hover:text-yellow-400 font-medium transition-colors">Gallery</Link>
              <Link href="/visit" className="text-white hover:text-yellow-400 font-medium transition-colors">Visit Us</Link>
              <Link href="/blog" className="text-yellow-400 font-medium">Blog</Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center pt-20">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=elegant%20blog%20and%20educational%20content%20showcase%20with%20books%20journals%20and%20writing%20materials%20luxury%20academic%20atmosphere%20warm%20golden%20lighting%20sophisticated%20scholarly%20setting&width=1920&height=1080&seq=bloghero&orientation=landscape')`
          }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/40"></div>
        
        <div className="relative z-10 text-center max-w-4xl mx-auto px-4">
          <h1 className="text-6xl md:text-8xl font-serif font-bold mb-8 text-yellow-400">
            Our Blog
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-12 font-light leading-relaxed">
            Educational insights, success stories, and expert guidance for your academic journey
          </p>
        </div>
      </section>

      {/* Category Filter */}
      <section className="py-12 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-4">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-6 py-3 rounded-full font-semibold transition-all duration-300 cursor-pointer whitespace-nowrap ${
                  activeCategory === category
                    ? 'bg-gradient-to-r from-yellow-600 to-yellow-400 text-black'
                    : 'bg-yellow-900/20 text-yellow-400 border border-yellow-800/30 hover:border-yellow-600/50'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Blog Posts */}
      <section className="py-20 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPosts.map((post) => (
              <article 
                key={post.id} 
                className="bg-gradient-to-br from-yellow-900/20 to-black rounded-xl overflow-hidden border border-yellow-800/30 hover:border-yellow-600/50 transition-all duration-300 group cursor-pointer hover:transform hover:scale-105"
              >
                <div className="h-48 overflow-hidden">
                  <img 
                    src={post.image} 
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                </div>
                
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <span className="px-3 py-1 bg-yellow-900/30 text-yellow-400 text-sm rounded-full border border-yellow-800/30">
                      {post.category}
                    </span>
                    <span className="text-gray-400 text-sm">{post.readTime}</span>
                  </div>
                  
                  <h2 className="text-xl font-serif font-bold text-yellow-400 mb-3 leading-tight">
                    {post.title}
                  </h2>
                  
                  <p className="text-gray-300 mb-4 leading-relaxed">
                    {post.excerpt}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center">
                        <span className="text-black text-xs font-bold">
                          {post.author.split(' ').map(name => name[0]).join('')}
                        </span>
                      </div>
                      <div>
                        <p className="text-yellow-400 font-semibold text-sm">{post.author}</p>
                        <p className="text-gray-400 text-xs">{post.date}</p>
                      </div>
                    </div>
                    
                    <button className="text-yellow-400 hover:text-yellow-300 transition-colors">
                      <i className="ri-arrow-right-line text-lg"></i>
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-20 bg-gray-900">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-gradient-to-br from-yellow-900/20 to-black rounded-xl p-12 border border-yellow-800/30">
            <div className="w-16 h-16 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="ri-mail-fill text-black text-2xl"></i>
            </div>
            <h2 className="text-3xl font-serif font-bold text-yellow-400 mb-4">
              Stay Updated
            </h2>
            <p className="text-gray-300 text-lg mb-8 leading-relaxed">
              Subscribe to our newsletter for the latest educational tips, success stories, and expert insights delivered to your inbox.
            </p>
            <form className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 bg-black/50 border border-yellow-800/30 rounded-lg px-4 py-3 text-white focus:border-yellow-600 focus:outline-none transition-colors"
              />
              <button
                type="submit"
                className="bg-gradient-to-r from-yellow-600 to-yellow-400 text-black px-6 py-3 rounded-lg font-semibold hover:from-yellow-500 hover:to-yellow-300 transition-all duration-300 cursor-pointer whitespace-nowrap"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16 border-t border-yellow-800/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center">
                  <i className="ri-graduation-cap-fill text-black text-lg"></i>
                </div>
                <div>
                  <h3 className="text-xl font-bold font-serif text-yellow-400">New Punjab School</h3>
                  <p className="text-sm text-yellow-300">& College</p>
                </div>
              </div>
              <p className="text-gray-400 leading-relaxed">
                Luxury education services where academic excellence meets sophisticated learning experiences.
              </p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4 text-yellow-400">Quick Links</h4>
              <ul className="space-y-2">
                <li><Link href="/" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Home</Link></li>
                <li><Link href="/story" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Our Story</Link></li>
                <li><Link href="/menu" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Menu</Link></li>
                <li><Link href="/gallery" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Gallery</Link></li>
                <li><Link href="/visit" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Visit Us</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4 text-yellow-400">Education Levels</h4>
              <ul className="space-y-2">
                <li className="text-gray-400">Matric Excellence</li>
                <li className="text-gray-400">F.Sc Mastery</li>
                <li className="text-gray-400">I.Com Premium</li>
                <li className="text-gray-400">B.Com & B.Sc Elite</li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4 text-yellow-400">Contact</h4>
              <div className="space-y-3">
                <p className="text-gray-400 flex items-center">
                  <i className="ri-phone-fill mr-3 text-yellow-400"></i>
                  03010600547
                </p>
                <p className="text-gray-400 flex items-center">
                  <i className="ri-map-pin-fill mr-3 text-yellow-400"></i>
                  Cavalry Street 6, Lahore
                </p>
                <p className="text-gray-400 flex items-center">
                  <i className="ri-time-fill mr-3 text-yellow-400"></i>
                  Mon-Sat: 8AM-10PM
                </p>
              </div>
            </div>
          </div>
          
          <div className="border-t border-yellow-800/20 mt-12 pt-8 text-center">
            <p className="text-gray-400">
              © 2024 New Punjab School & College. Where futures begin.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}