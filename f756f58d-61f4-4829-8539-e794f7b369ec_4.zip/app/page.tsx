'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';

export default function Home() {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Fixed Transparent Navbar */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        scrollY > 100 ? 'bg-black/80 backdrop-blur-lg' : 'bg-transparent'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center">
                <i className="ri-graduation-cap-fill text-black text-xl"></i>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-yellow-400 font-serif">
                  New Punjab School
                </h1>
                <p className="text-sm text-yellow-300">& College</p>
              </div>
            </Link>
            <div className="hidden md:flex space-x-8">
              <Link href="/" className="text-white hover:text-yellow-400 font-medium transition-colors">Home</Link>
              <Link href="/story" className="text-white hover:text-yellow-400 font-medium transition-colors">Our Story</Link>
              <Link href="/menu" className="text-white hover:text-yellow-400 font-medium transition-colors">Menu</Link>
              <Link href="/gallery" className="text-white hover:text-yellow-400 font-medium transition-colors">Gallery</Link>
              <Link href="/visit" className="text-white hover:text-yellow-400 font-medium transition-colors">Visit Us</Link>
              <Link href="/blog" className="text-white hover:text-yellow-400 font-medium transition-colors">Blog</Link>
            </div>
            <div className="md:hidden">
              <button className="text-white hover:text-yellow-400">
                <i className="ri-menu-line text-2xl"></i>
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Full-Screen Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=luxurious%20dark%20moody%20educational%20environment%20with%20warm%20golden%20lighting%20textured%20walls%20books%20scattered%20on%20wooden%20table%20elegant%20serif%20typography%20atmosphere%20deep%20shadows%20and%20warm%20highlights%20sophisticated%20academic%20setting&width=1920&height=1080&seq=hero1&orientation=landscape')`
          }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40"></div>
        
        <div className="relative z-10 text-center max-w-4xl mx-auto px-4">
          <h1 className="text-6xl md:text-8xl font-serif font-bold mb-8 text-yellow-400 animate-fade-in">
            Step to Your Future
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-12 font-light leading-relaxed">
            Where academic excellence meets luxury education in the heart of Lahore
          </p>
          <Link 
            href="/menu"
            className="inline-block bg-gradient-to-r from-yellow-600 to-yellow-400 text-black px-12 py-4 rounded-full font-semibold text-lg hover:from-yellow-500 hover:to-yellow-300 transition-all duration-300 transform hover:scale-105 cursor-pointer whitespace-nowrap"
          >
            Browse Menu
          </Link>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <i className="ri-arrow-down-line text-yellow-400 text-2xl"></i>
        </div>
      </section>

      {/* Student Mood Picker */}
      <section className="py-20 bg-gradient-to-b from-black to-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-yellow-400 mb-6">
              Find Your Perfect Teacher
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Tell us your mood, and we'll suggest the perfect tutor for your learning style
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-yellow-900/20 to-yellow-800/10 rounded-xl p-8 border border-yellow-800/30 hover:border-yellow-600/50 transition-all duration-300 cursor-pointer group">
              <div className="w-16 h-16 bg-yellow-600/20 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-yellow-600/30 transition-colors">
                <i className="ri-sun-fill text-yellow-400 text-2xl"></i>
              </div>
              <h3 className="text-2xl font-serif font-bold text-yellow-400 mb-4 text-center">Energetic Learner</h3>
              <p className="text-gray-300 text-center leading-relaxed">
                Dynamic, interactive sessions with engaging activities and hands-on learning approaches
              </p>
            </div>
            
            <div className="bg-gradient-to-br from-yellow-900/20 to-yellow-800/10 rounded-xl p-8 border border-yellow-800/30 hover:border-yellow-600/50 transition-all duration-300 cursor-pointer group">
              <div className="w-16 h-16 bg-yellow-600/20 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-yellow-600/30 transition-colors">
                <i className="ri-book-open-fill text-yellow-400 text-2xl"></i>
              </div>
              <h3 className="text-2xl font-serif font-bold text-yellow-400 mb-4 text-center">Focused Scholar</h3>
              <p className="text-gray-300 text-center leading-relaxed">
                Structured, methodical teaching with detailed explanations and comprehensive coverage
              </p>
            </div>
            
            <div className="bg-gradient-to-br from-yellow-900/20 to-yellow-800/10 rounded-xl p-8 border border-yellow-800/30 hover:border-yellow-600/50 transition-all duration-300 cursor-pointer group">
              <div className="w-16 h-16 bg-yellow-600/20 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-yellow-600/30 transition-colors">
                <i className="ri-heart-fill text-yellow-400 text-2xl"></i>
              </div>
              <h3 className="text-2xl font-serif font-bold text-yellow-400 mb-4 text-center">Creative Mind</h3>
              <p className="text-gray-300 text-center leading-relaxed">
                Innovative teaching methods with creative problem-solving and artistic approaches
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Student Wall */}
      <section className="py-20 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-yellow-400 mb-6">
              Student Voices
            </h2>
            <p className="text-xl text-gray-300">
              Hear from our successful students who stepped into their future
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-yellow-900/10 to-black rounded-xl p-6 border border-yellow-800/20 hover:border-yellow-600/40 transition-all duration-300">
              <div className="flex items-center mb-4">
                <div className="w-16 h-16 rounded-full bg-gradient-to-r from-yellow-600 to-yellow-400 flex items-center justify-center mr-4">
                  <span className="text-black font-bold text-lg">AH</span>
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-yellow-400">Ahmed Hassan</h4>
                  <p className="text-gray-400 text-sm">F.Sc Pre-Medical</p>
                </div>
              </div>
              <p className="text-gray-300 italic leading-relaxed">
                "The personalized attention helped me achieve 98% in my board exams. Now I'm studying medicine at King Edward Medical University."
              </p>
            </div>
            
            <div className="bg-gradient-to-br from-yellow-900/10 to-black rounded-xl p-6 border border-yellow-800/20 hover:border-yellow-600/40 transition-all duration-300">
              <div className="flex items-center mb-4">
                <div className="w-16 h-16 rounded-full bg-gradient-to-r from-yellow-600 to-yellow-400 flex items-center justify-center mr-4">
                  <span className="text-black font-bold text-lg">SF</span>
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-yellow-400">Sara Fatima</h4>
                  <p className="text-gray-400 text-sm">I.Com Graduate</p>
                </div>
              </div>
              <p className="text-gray-300 italic leading-relaxed">
                "The home tuition service was perfect for my busy schedule. I could balance work and studies effectively."
              </p>
            </div>
            
            <div className="bg-gradient-to-br from-yellow-900/10 to-black rounded-xl p-6 border border-yellow-800/20 hover:border-yellow-600/40 transition-all duration-300">
              <div className="flex items-center mb-4">
                <div className="w-16 h-16 rounded-full bg-gradient-to-r from-yellow-600 to-yellow-400 flex items-center justify-center mr-4">
                  <span className="text-black font-bold text-lg">MR</span>
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-yellow-400">Muhammad Raza</h4>
                  <p className="text-gray-400 text-sm">B.Sc Mathematics</p>
                </div>
              </div>
              <p className="text-gray-300 italic leading-relaxed">
                "The tutors made complex mathematical concepts simple and understandable. Highly recommended!"
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Preview */}
      <section className="py-20 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-yellow-400 mb-6">
              Premium Education Services
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Luxury learning experiences tailored to your academic journey
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-yellow-900/20 to-black rounded-xl p-8 border border-yellow-800/30 hover:border-yellow-600/50 transition-all duration-300 group">
              <div className="w-16 h-16 bg-yellow-600/20 rounded-full flex items-center justify-center mb-6 group-hover:bg-yellow-600/30 transition-colors">
                <i className="ri-home-4-fill text-yellow-400 text-2xl"></i>
              </div>
              <h3 className="text-2xl font-serif font-bold text-yellow-400 mb-4">Premium Home Tuition</h3>
              <p className="text-gray-300 mb-6 leading-relaxed">
                Personalized one-on-one sessions in the comfort of your home with our elite tutors
              </p>
              <div className="text-yellow-400 font-bold text-xl">PKR 6,500/month</div>
            </div>
            
            <div className="bg-gradient-to-br from-yellow-900/20 to-black rounded-xl p-8 border border-yellow-800/30 hover:border-yellow-600/50 transition-all duration-300 group">
              <div className="w-16 h-16 bg-yellow-600/20 rounded-full flex items-center justify-center mb-6 group-hover:bg-yellow-600/30 transition-colors">
                <i className="ri-group-fill text-yellow-400 text-2xl"></i>
              </div>
              <h3 className="text-2xl font-serif font-bold text-yellow-400 mb-4">Elite Group Sessions</h3>
              <p className="text-gray-300 mb-6 leading-relaxed">
                Small group learning with peer interaction and collaborative problem-solving
              </p>
              <div className="text-yellow-400 font-bold text-xl">PKR 5,000/month</div>
            </div>
            
            <div className="bg-gradient-to-br from-yellow-900/20 to-black rounded-xl p-8 border border-yellow-800/30 hover:border-yellow-600/50 transition-all duration-300 group">
              <div className="w-16 h-16 bg-yellow-600/20 rounded-full flex items-center justify-center mb-6 group-hover:bg-yellow-600/30 transition-colors">
                <i className="ri-trophy-fill text-yellow-400 text-2xl"></i>
              </div>
              <h3 className="text-2xl font-serif font-bold text-yellow-400 mb-4">Exam Mastery</h3>
              <p className="text-gray-300 mb-6 leading-relaxed">
                Intensive preparation with mock tests and strategic guidance for top performance
              </p>
              <div className="text-yellow-400 font-bold text-xl">PKR 8,000/month</div>
            </div>
          </div>
          
          <div className="text-center mt-12">
            <Link 
              href="/menu"
              className="inline-block bg-gradient-to-r from-yellow-600 to-yellow-400 text-black px-8 py-3 rounded-full font-semibold hover:from-yellow-500 hover:to-yellow-300 transition-all duration-300 cursor-pointer whitespace-nowrap"
            >
              View All Services
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16 border-t border-yellow-800/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center">
                  <i className="ri-graduation-cap-fill text-black text-lg"></i>
                </div>
                <div>
                  <h3 className="text-xl font-bold font-serif text-yellow-400">New Punjab School</h3>
                  <p className="text-sm text-yellow-300">& College</p>
                </div>
              </div>
              <p className="text-gray-400 leading-relaxed">
                Luxury education services where academic excellence meets sophisticated learning experiences.
              </p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4 text-yellow-400">Quick Links</h4>
              <ul className="space-y-2">
                <li><Link href="/story" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Our Story</Link></li>
                <li><Link href="/menu" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Services Menu</Link></li>
                <li><Link href="/gallery" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Gallery</Link></li>
                <li><Link href="/blog" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Blog</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4 text-yellow-400">Education Levels</h4>
              <ul className="space-y-2">
                <li className="text-gray-400">Matric Excellence</li>
                <li className="text-gray-400">F.Sc Mastery</li>
                <li className="text-gray-400">I.Com Premium</li>
                <li className="text-gray-400">B.Com & B.Sc Elite</li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4 text-yellow-400">Contact</h4>
              <div className="space-y-3">
                <p className="text-gray-400 flex items-center">
                  <i className="ri-phone-fill mr-3 text-yellow-400"></i>
                  03010600547
                </p>
                <p className="text-gray-400 flex items-center">
                  <i className="ri-map-pin-fill mr-3 text-yellow-400"></i>
                  Cavalry Street 6, Lahore
                </p>
                <p className="text-gray-400 flex items-center">
                  <i className="ri-time-fill mr-3 text-yellow-400"></i>
                  Mon-Sat: 8AM-10PM
                </p>
              </div>
            </div>
          </div>
          
          <div className="border-t border-yellow-800/20 mt-12 pt-8 text-center">
            <p className="text-gray-400">
              © 2024 New Punjab School & College. Where futures begin.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}