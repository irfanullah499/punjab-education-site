'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';

interface CheckoutDetailProps {
  serviceId: string;
}

export default function CheckoutDetail({ serviceId }: CheckoutDetailProps) {
  const [scrollY, setScrollY] = useState(0);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    address: '',
    preferredTime: '',
    additionalNotes: ''
  });

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const services = {
    '1': {
      name: "Premium Home Tuition",
      price: "PKR 6,500",
      description: "Personalized one-on-one sessions with elite tutors in the comfort of your home",
      features: ["Custom learning plans", "Flexible scheduling", "Progress tracking", "Regular assessments"],
      image: "https://readdy.ai/api/search-image?query=luxury%20home%20tutoring%20session%20elegant%20living%20room%20with%20student%20and%20professional%20tutor%20books%20and%20notebooks%20warm%20golden%20lighting%20sophisticated%20educational%20setting&width=600&height=400&seq=checkout1&orientation=landscape"
    },
    '2': {
      name: "Elite Group Sessions",
      price: "PKR 5,000",
      description: "Small group learning with peer interaction and collaborative problem-solving",
      features: ["Interactive discussions", "Peer learning", "Cost-effective", "Competitive environment"],
      image: "https://readdy.ai/api/search-image?query=small%20group%20of%20students%20studying%20together%20with%20professional%20tutor%20in%20elegant%20room%20warm%20golden%20lighting%20luxury%20educational%20setting%20collaborative%20learning%20environment&width=600&height=400&seq=checkout2&orientation=landscape"
    },
    '3': {
      name: "Exam Mastery Program",
      price: "PKR 8,000",
      description: "Intensive preparation with mock tests and strategic guidance for top performance",
      features: ["Mock examinations", "Past papers practice", "Time management", "Subject-specific guidance"],
      image: "https://readdy.ai/api/search-image?query=exam%20preparation%20session%20with%20student%20and%20tutor%20practice%20papers%20textbooks%20elegant%20study%20room%20warm%20golden%20lighting%20focused%20academic%20atmosphere%20luxury%20setting&width=600&height=400&seq=checkout3&orientation=landscape"
    },
    '4': {
      name: "Matric Excellence",
      price: "PKR 5,500",
      description: "Complete preparation for matriculation exams with focus on core subjects",
      features: ["All core subjects", "Board exam prep", "Regular testing", "Performance analysis"],
      image: "https://readdy.ai/api/search-image?query=matric%20level%20student%20studying%20with%20tutor%20textbooks%20and%20educational%20materials%20elegant%20study%20environment%20warm%20golden%20lighting%20academic%20excellence%20luxury%20educational%20setting&width=600&height=400&seq=checkout4&orientation=landscape"
    },
    '5': {
      name: "F.Sc Mastery",
      price: "PKR 7,000",
      description: "Specialized coaching for FSc students preparing for university entrance",
      features: ["Pre-Medical/Pre-Engineering", "University prep", "Concept building", "Problem solving"],
      image: "https://readdy.ai/api/search-image?query=FSc%20level%20advanced%20mathematics%20and%20science%20tutoring%20session%20with%20professional%20tutor%20elegant%20study%20room%20warm%20golden%20lighting%20luxury%20educational%20environment&width=600&height=400&seq=checkout5&orientation=landscape"
    },
    '6': {
      name: "Commerce Premium",
      price: "PKR 6,000",
      description: "Comprehensive commerce education for I.Com and B.Com students",
      features: ["Accounting mastery", "Business studies", "Economics focus", "Practical applications"],
      image: "https://readdy.ai/api/search-image?query=commerce%20and%20business%20studies%20tutoring%20session%20with%20charts%20graphs%20and%20business%20books%20elegant%20office%20setting%20warm%20golden%20lighting%20luxury%20educational%20environment&width=600&height=400&seq=checkout6&orientation=landscape"
    },
    '7': {
      name: "Science Elite Program",
      price: "PKR 6,800",
      description: "Advanced science subjects for B.Sc students with practical components",
      features: ["Physics mastery", "Chemistry labs", "Mathematics excellence", "Research methods"],
      image: "https://readdy.ai/api/search-image?query=science%20tutoring%20session%20with%20laboratory%20equipment%20books%20and%20scientific%20materials%20elegant%20study%20room%20warm%20golden%20lighting%20luxury%20educational%20setting%20academic%20excellence&width=600&height=400&seq=checkout7&orientation=landscape"
    },
    '8': {
      name: "Online Luxury Learning",
      price: "PKR 5,800",
      description: "Premium online tutoring with interactive tools and digital resources",
      features: ["Interactive whiteboards", "Recorded sessions", "Digital resources", "Flexible timing"],
      image: "https://readdy.ai/api/search-image?query=online%20learning%20setup%20with%20elegant%20computer%20screen%20showing%20virtual%20classroom%20luxury%20home%20office%20setting%20warm%20golden%20lighting%20modern%20educational%20technology&width=600&height=400&seq=checkout8&orientation=landscape"
    },
    '9': {
      name: "Intensive Crash Course",
      price: "PKR 7,500",
      description: "Short-term intensive courses for quick exam preparation and concept revision",
      features: ["Rapid concept building", "Intensive practice", "Quick revision", "Last-minute prep"],
      image: "https://readdy.ai/api/search-image?query=intensive%20study%20session%20with%20multiple%20textbooks%20notes%20and%20practice%20papers%20elegant%20study%20room%20warm%20golden%20lighting%20focused%20academic%20atmosphere%20luxury%20educational%20setting&width=600&height=400&seq=checkout9&orientation=landscape"
    }
  };

  const service = services[serviceId as keyof typeof services];

  if (!service) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-serif font-bold text-yellow-400 mb-4">Service Not Found</h1>
          <Link href="/menu" className="text-yellow-400 hover:text-yellow-300">
            Return to Menu
          </Link>
        </div>
      </div>
    );
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleWhatsAppOrder = () => {
    const message = `🎓 *New Order from New Punjab School & College*

📚 *Service:* ${service.name}
💰 *Price:* ${service.price}/month

👤 *Customer Details:*
• Name: ${formData.name}
• Phone: ${formData.phone}
• Email: ${formData.email}
• Address: ${formData.address}
• Preferred Time: ${formData.preferredTime}

📝 *Additional Notes:*
${formData.additionalNotes || 'None'}

💳 *Payment:* Cash on Delivery

Please confirm this order and schedule the first session. Thank you!`;

    const whatsappUrl = `https://wa.me/923010600547?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Fixed Transparent Navbar */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        scrollY > 100 ? 'bg-black/80 backdrop-blur-lg' : 'bg-transparent'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center">
                <i className="ri-graduation-cap-fill text-black text-xl"></i>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-yellow-400 font-serif">
                  New Punjab School
                </h1>
                <p className="text-sm text-yellow-300">& College</p>
              </div>
            </Link>
            <div className="hidden md:flex space-x-8">
              <Link href="/" className="text-white hover:text-yellow-400 font-medium transition-colors">Home</Link>
              <Link href="/story" className="text-white hover:text-yellow-400 font-medium transition-colors">Our Story</Link>
              <Link href="/menu" className="text-white hover:text-yellow-400 font-medium transition-colors">Menu</Link>
              <Link href="/gallery" className="text-white hover:text-yellow-400 font-medium transition-colors">Gallery</Link>
              <Link href="/visit" className="text-white hover:text-yellow-400 font-medium transition-colors">Visit Us</Link>
              <Link href="/blog" className="text-white hover:text-yellow-400 font-medium transition-colors">Blog</Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="pt-24 pb-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            
            {/* Service Details */}
            <div className="bg-gradient-to-br from-yellow-900/20 to-black rounded-xl p-8 border border-yellow-800/30">
              <div className="mb-6">
                <img 
                  src={service.image} 
                  alt={service.name}
                  className="w-full h-64 object-cover rounded-lg"
                />
              </div>
              
              <h1 className="text-3xl font-serif font-bold text-yellow-400 mb-4">{service.name}</h1>
              <div className="text-2xl font-bold text-yellow-400 mb-6">{service.price}/month</div>
              
              <p className="text-gray-300 mb-6 leading-relaxed">{service.description}</p>
              
              <h3 className="text-xl font-serif font-bold text-yellow-400 mb-4">What's Included:</h3>
              <ul className="space-y-3 mb-8">
                {service.features.map((feature, index) => (
                  <li key={index} className="flex items-center text-gray-300">
                    <i className="ri-check-line text-yellow-400 mr-3"></i>
                    {feature}
                  </li>
                ))}
              </ul>
              
              <div className="bg-yellow-900/20 rounded-lg p-4 border border-yellow-800/30">
                <div className="flex items-center mb-2">
                  <i className="ri-cash-fill text-yellow-400 mr-2"></i>
                  <span className="font-semibold text-yellow-400">Cash on Delivery</span>
                </div>
                <p className="text-gray-300 text-sm">
                  No advance payment required. Pay conveniently when our tutor arrives for your first session.
                </p>
              </div>
            </div>

            {/* Order Form */}
            <div className="bg-gradient-to-br from-yellow-900/20 to-black rounded-xl p-8 border border-yellow-800/30">
              <h2 className="text-2xl font-serif font-bold text-yellow-400 mb-6">Book Your Session</h2>
              
              <form id="checkout-form" className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-yellow-400 font-semibold mb-2">Full Name *</label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full bg-black/50 border border-yellow-800/30 rounded-lg px-4 py-3 text-white focus:border-yellow-600 focus:outline-none transition-colors"
                    placeholder="Enter your full name"
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="phone" className="block text-yellow-400 font-semibold mb-2">Phone Number *</label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="w-full bg-black/50 border border-yellow-800/30 rounded-lg px-4 py-3 text-white focus:border-yellow-600 focus:outline-none transition-colors"
                    placeholder="03xxxxxxxxx"
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-yellow-400 font-semibold mb-2">Email Address</label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full bg-black/50 border border-yellow-800/30 rounded-lg px-4 py-3 text-white focus:border-yellow-600 focus:outline-none transition-colors"
                    placeholder="your.email@example.com"
                  />
                </div>
                
                <div>
                  <label htmlFor="address" className="block text-yellow-400 font-semibold mb-2">Home Address *</label>
                  <textarea
                    id="address"
                    name="address"
                    value={formData.address}
                    onChange={handleInputChange}
                    rows={3}
                    maxLength={500}
                    className="w-full bg-black/50 border border-yellow-800/30 rounded-lg px-4 py-3 text-white focus:border-yellow-600 focus:outline-none transition-colors resize-none"
                    placeholder="Enter your complete home address for tutor visit"
                    required
                  ></textarea>
                  <div className="text-right text-gray-400 text-sm mt-1">
                    {formData.address.length}/500 characters
                  </div>
                </div>
                
                <div>
                  <label htmlFor="preferredTime" className="block text-yellow-400 font-semibold mb-2">Preferred Time</label>
                  <select
                    id="preferredTime"
                    name="preferredTime"
                    value={formData.preferredTime}
                    onChange={handleInputChange}
                    className="w-full bg-black/50 border border-yellow-800/30 rounded-lg px-4 py-3 text-white focus:border-yellow-600 focus:outline-none transition-colors pr-8"
                  >
                    <option value="">Select preferred time</option>
                    <option value="Morning (8AM-12PM)">Morning (8AM-12PM)</option>
                    <option value="Afternoon (12PM-5PM)">Afternoon (12PM-5PM)</option>
                    <option value="Evening (5PM-8PM)">Evening (5PM-8PM)</option>
                    <option value="Night (8PM-10PM)">Night (8PM-10PM)</option>
                  </select>
                </div>
                
                <div>
                  <label htmlFor="additionalNotes" className="block text-yellow-400 font-semibold mb-2">Additional Notes</label>
                  <textarea
                    id="additionalNotes"
                    name="additionalNotes"
                    value={formData.additionalNotes}
                    onChange={handleInputChange}
                    rows={4}
                    maxLength={500}
                    className="w-full bg-black/50 border border-yellow-800/30 rounded-lg px-4 py-3 text-white focus:border-yellow-600 focus:outline-none transition-colors resize-none"
                    placeholder="Any specific requirements, subjects to focus on, or other details..."
                  ></textarea>
                  <div className="text-right text-gray-400 text-sm mt-1">
                    {formData.additionalNotes.length}/500 characters
                  </div>
                </div>
                
                <button
                  type="button"
                  onClick={handleWhatsAppOrder}
                  disabled={!formData.name || !formData.phone || !formData.address || formData.address.length > 500 || formData.additionalNotes.length > 500}
                  className="w-full bg-gradient-to-r from-yellow-600 to-yellow-400 text-black py-4 rounded-lg font-semibold text-lg hover:from-yellow-500 hover:to-yellow-300 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-whatsapp-fill mr-2 text-xl"></i>
                  Order via WhatsApp
                </button>
              </form>
              
              <div className="mt-6 text-center">
                <p className="text-gray-400 text-sm">
                  By placing this order, you agree to our terms of service. 
                  Our team will contact you within 24 hours to confirm your booking.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}