'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';

export default function Gallery() {
  const [scrollY, setScrollY] = useState(0);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const galleryImages = [
    {
      id: 1,
      src: "https://readdy.ai/api/search-image?query=elegant%20classroom%20with%20students%20studying%20luxury%20educational%20environment%20warm%20golden%20lighting%20sophisticated%20academic%20setting%20beautiful%20interior%20design&width=400&height=600&seq=gallery1&orientation=portrait",
      alt: "Elegant Classroom Environment",
      category: "classrooms"
    },
    {
      id: 2,
      src: "https://readdy.ai/api/search-image?query=professional%20tutor%20teaching%20student%20one%20on%20one%20session%20luxury%20home%20setting%20warm%20golden%20lighting%20educational%20excellence%20sophisticated%20atmosphere&width=600&height=400&seq=gallery2&orientation=landscape",
      alt: "One-on-One Tutoring",
      category: "tutoring"
    },
    {
      id: 3,
      src: "https://readdy.ai/api/search-image?query=students%20celebrating%20academic%20achievement%20graduation%20ceremony%20luxury%20educational%20setting%20warm%20golden%20lighting%20success%20moments&width=400&height=500&seq=gallery3&orientation=portrait",
      alt: "Academic Success",
      category: "achievements"
    },
    {
      id: 4,
      src: "https://readdy.ai/api/search-image?query=modern%20library%20with%20books%20and%20study%20materials%20luxury%20educational%20environment%20warm%20golden%20lighting%20sophisticated%20academic%20atmosphere&width=500&height=400&seq=gallery4&orientation=landscape",
      alt: "Premium Library",
      category: "facilities"
    },
    {
      id: 5,
      src: "https://readdy.ai/api/search-image?query=group%20study%20session%20with%20multiple%20students%20collaborative%20learning%20luxury%20educational%20setting%20warm%20golden%20lighting%20academic%20excellence&width=400&height=600&seq=gallery5&orientation=portrait",
      alt: "Group Study Sessions",
      category: "tutoring"
    },
    {
      id: 6,
      src: "https://readdy.ai/api/search-image?query=science%20laboratory%20with%20modern%20equipment%20luxury%20educational%20facility%20warm%20golden%20lighting%20advanced%20academic%20setting%20sophisticated%20atmosphere&width=600&height=400&seq=gallery6&orientation=landscape",
      alt: "Science Laboratory",
      category: "facilities"
    },
    {
      id: 7,
      src: "https://readdy.ai/api/search-image?query=mathematics%20tutoring%20session%20with%20equations%20and%20formulas%20luxury%20educational%20environment%20warm%20golden%20lighting%20academic%20excellence%20sophisticated%20setting&width=400&height=500&seq=gallery7&orientation=portrait",
      alt: "Mathematics Excellence",
      category: "tutoring"
    },
    {
      id: 8,
      src: "https://readdy.ai/api/search-image?query=student%20receiving%20award%20certificate%20luxury%20educational%20ceremony%20warm%20golden%20lighting%20achievement%20recognition%20sophisticated%20atmosphere&width=500&height=400&seq=gallery8&orientation=landscape",
      alt: "Achievement Recognition",
      category: "achievements"
    },
    {
      id: 9,
      src: "https://readdy.ai/api/search-image?query=comfortable%20study%20lounge%20with%20elegant%20furniture%20luxury%20educational%20environment%20warm%20golden%20lighting%20sophisticated%20academic%20setting&width=400&height=600&seq=gallery9&orientation=portrait",
      alt: "Study Lounge",
      category: "facilities"
    },
    {
      id: 10,
      src: "https://readdy.ai/api/search-image?query=exam%20preparation%20session%20with%20practice%20papers%20luxury%20educational%20setting%20warm%20golden%20lighting%20focused%20academic%20atmosphere%20sophisticated%20environment&width=600&height=400&seq=gallery10&orientation=landscape",
      alt: "Exam Preparation",
      category: "tutoring"
    },
    {
      id: 11,
      src: "https://readdy.ai/api/search-image?query=students%20with%20academic%20awards%20and%20certificates%20luxury%20educational%20achievement%20warm%20golden%20lighting%20success%20celebration%20sophisticated%20setting&width=400&height=500&seq=gallery11&orientation=portrait",
      alt: "Academic Awards",
      category: "achievements"
    },
    {
      id: 12,
      src: "https://readdy.ai/api/search-image?query=elegant%20reception%20area%20with%20modern%20furniture%20luxury%20educational%20facility%20warm%20golden%20lighting%20sophisticated%20academic%20environment&width=500&height=400&seq=gallery12&orientation=landscape",
      alt: "Reception Area",
      category: "facilities"
    }
  ];

  const categories = [
    { id: 'all', name: 'All' },
    { id: 'classrooms', name: 'Classrooms' },
    { id: 'tutoring', name: 'Tutoring' },
    { id: 'facilities', name: 'Facilities' },
    { id: 'achievements', name: 'Achievements' }
  ];

  const [activeCategory, setActiveCategory] = useState('all');

  const filteredImages = activeCategory === 'all' 
    ? galleryImages 
    : galleryImages.filter(img => img.category === activeCategory);

  const openLightbox = (imageSrc: string) => {
    setSelectedImage(imageSrc);
  };

  const closeLightbox = () => {
    setSelectedImage(null);
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Fixed Transparent Navbar */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        scrollY > 100 ? 'bg-black/80 backdrop-blur-lg' : 'bg-transparent'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center">
                <i className="ri-graduation-cap-fill text-black text-xl"></i>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-yellow-400 font-serif">
                  New Punjab School
                </h1>
                <p className="text-sm text-yellow-300">& College</p>
              </div>
            </Link>
            <div className="hidden md:flex space-x-8">
              <Link href="/" className="text-white hover:text-yellow-400 font-medium transition-colors">Home</Link>
              <Link href="/story" className="text-white hover:text-yellow-400 font-medium transition-colors">Our Story</Link>
              <Link href="/menu" className="text-white hover:text-yellow-400 font-medium transition-colors">Menu</Link>
              <Link href="/gallery" className="text-yellow-400 font-medium">Gallery</Link>
              <Link href="/visit" className="text-white hover:text-yellow-400 font-medium transition-colors">Visit Us</Link>
              <Link href="/blog" className="text-white hover:text-yellow-400 font-medium transition-colors">Blog</Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center pt-20">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=elegant%20gallery%20showcase%20with%20multiple%20framed%20pictures%20warm%20golden%20lighting%20luxury%20educational%20environment%20sophisticated%20academic%20atmosphere%20art%20display&width=1920&height=1080&seq=galleryhero&orientation=landscape')`
          }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/40"></div>
        
        <div className="relative z-10 text-center max-w-4xl mx-auto px-4">
          <h1 className="text-6xl md:text-8xl font-serif font-bold mb-8 text-yellow-400">
            Gallery
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-12 font-light leading-relaxed">
            Witness the moments that define academic excellence and luxury learning
          </p>
        </div>
      </section>

      {/* Filter Categories */}
      <section className="py-12 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-4">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`px-6 py-3 rounded-full font-semibold transition-all duration-300 cursor-pointer whitespace-nowrap ${
                  activeCategory === category.id
                    ? 'bg-gradient-to-r from-yellow-600 to-yellow-400 text-black'
                    : 'bg-yellow-900/20 text-yellow-400 border border-yellow-800/30 hover:border-yellow-600/50'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Masonry Gallery */}
      <section className="py-20 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="columns-1 md:columns-2 lg:columns-3 xl:columns-4 gap-6">
            {filteredImages.map((image) => (
              <div
                key={image.id}
                className="mb-6 break-inside-avoid cursor-pointer group"
                onClick={() => openLightbox(image.src)}
              >
                <div className="relative overflow-hidden rounded-xl border border-yellow-800/30 hover:border-yellow-600/50 transition-all duration-300">
                  <img
                    src={image.src}
                    alt={image.alt}
                    className="w-full h-auto object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-white font-semibold text-lg">{image.alt}</h3>
                    </div>
                  </div>
                  <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="w-10 h-10 bg-yellow-400/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                      <i className="ri-zoom-in-line text-yellow-400 text-lg"></i>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Lightbox */}
      {selectedImage && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4">
          <div className="relative max-w-5xl max-h-full">
            <button
              onClick={closeLightbox}
              className="absolute top-4 right-4 w-12 h-12 bg-black/50 rounded-full flex items-center justify-center text-white hover:bg-black/70 transition-colors z-10"
            >
              <i className="ri-close-line text-2xl"></i>
            </button>
            <img
              src={selectedImage}
              alt="Gallery Image"
              className="max-w-full max-h-full object-contain rounded-lg"
            />
          </div>
        </div>
      )}

      {/* Stats Section */}
      <section className="py-20 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-yellow-400 mb-6">
              Our Achievements in Numbers
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              These moments represent the dedication and success of our students and faculty
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-5xl font-bold text-yellow-400 mb-4">500+</div>
              <div className="text-gray-300 text-lg">Students Taught</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-yellow-400 mb-4">98%</div>
              <div className="text-gray-300 text-lg">Success Rate</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-yellow-400 mb-4">50+</div>
              <div className="text-gray-300 text-lg">Awards Won</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-yellow-400 mb-4">5+</div>
              <div className="text-gray-300 text-lg">Years Excellence</div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16 border-t border-yellow-800/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center">
                  <i className="ri-graduation-cap-fill text-black text-lg"></i>
                </div>
                <div>
                  <h3 className="text-xl font-bold font-serif text-yellow-400">New Punjab School</h3>
                  <p className="text-sm text-yellow-300">& College</p>
                </div>
              </div>
              <p className="text-gray-400 leading-relaxed">
                Luxury education services where academic excellence meets sophisticated learning experiences.
              </p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4 text-yellow-400">Quick Links</h4>
              <ul className="space-y-2">
                <li><Link href="/" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Home</Link></li>
                <li><Link href="/story" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Our Story</Link></li>
                <li><Link href="/menu" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Menu</Link></li>
                <li><Link href="/blog" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Blog</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4 text-yellow-400">Education Levels</h4>
              <ul className="space-y-2">
                <li className="text-gray-400">Matric Excellence</li>
                <li className="text-gray-400">F.Sc Mastery</li>
                <li className="text-gray-400">I.Com Premium</li>
                <li className="text-gray-400">B.Com & B.Sc Elite</li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4 text-yellow-400">Contact</h4>
              <div className="space-y-3">
                <p className="text-gray-400 flex items-center">
                  <i className="ri-phone-fill mr-3 text-yellow-400"></i>
                  03010600547
                </p>
                <p className="text-gray-400 flex items-center">
                  <i className="ri-map-pin-fill mr-3 text-yellow-400"></i>
                  Cavalry Street 6, Lahore
                </p>
                <p className="text-gray-400 flex items-center">
                  <i className="ri-time-fill mr-3 text-yellow-400"></i>
                  Mon-Sat: 8AM-10PM
                </p>
              </div>
            </div>
          </div>
          
          <div className="border-t border-yellow-800/20 mt-12 pt-8 text-center">
            <p className="text-gray-400">
              © 2024 New Punjab School & College. Where futures begin.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}