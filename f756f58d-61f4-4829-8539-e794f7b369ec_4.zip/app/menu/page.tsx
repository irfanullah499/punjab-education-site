'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';

export default function Menu() {
  const [scrollY, setScrollY] = useState(0);
  const [activeFilter, setActiveFilter] = useState('all');

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = [
    {
      id: 1,
      name: "Premium Home Tuition",
      category: "individual",
      price: "PKR 6,500",
      description: "Personalized one-on-one sessions with elite tutors in the comfort of your home",
      features: ["Custom learning plans", "Flexible scheduling", "Progress tracking", "Regular assessments"],
      image: "https://readdy.ai/api/search-image?query=luxury%20home%20tutoring%20session%20elegant%20living%20room%20with%20student%20and%20professional%20tutor%20books%20and%20notebooks%20warm%20golden%20lighting%20sophisticated%20educational%20setting&width=400&height=300&seq=menu1&orientation=landscape"
    },
    {
      id: 2,
      name: "Elite Group Sessions",
      category: "group",
      price: "PKR 5,000",
      description: "Small group learning with peer interaction and collaborative problem-solving",
      features: ["Interactive discussions", "Peer learning", "Cost-effective", "Competitive environment"],
      image: "https://readdy.ai/api/search-image?query=small%20group%20of%20students%20studying%20together%20with%20professional%20tutor%20in%20elegant%20room%20warm%20golden%20lighting%20luxury%20educational%20setting%20collaborative%20learning%20environment&width=400&height=300&seq=menu2&orientation=landscape"
    },
    {
      id: 3,
      name: "Exam Mastery Program",
      category: "exam",
      price: "PKR 8,000",
      description: "Intensive preparation with mock tests and strategic guidance for top performance",
      features: ["Mock examinations", "Past papers practice", "Time management", "Subject-specific guidance"],
      image: "https://readdy.ai/api/search-image?query=exam%20preparation%20session%20with%20student%20and%20tutor%20practice%20papers%20textbooks%20elegant%20study%20room%20warm%20golden%20lighting%20focused%20academic%20atmosphere%20luxury%20setting&width=400&height=300&seq=menu3&orientation=landscape"
    },
    {
      id: 4,
      name: "Matric Excellence",
      category: "level",
      price: "PKR 5,500",
      description: "Complete preparation for matriculation exams with focus on core subjects",
      features: ["All core subjects", "Board exam prep", "Regular testing", "Performance analysis"],
      image: "https://readdy.ai/api/search-image?query=matric%20level%20student%20studying%20with%20tutor%20textbooks%20and%20educational%20materials%20elegant%20study%20environment%20warm%20golden%20lighting%20academic%20excellence%20luxury%20educational%20setting&width=400&height=300&seq=menu4&orientation=landscape"
    },
    {
      id: 5,
      name: "F.Sc Mastery",
      category: "level",
      price: "PKR 7,000",
      description: "Specialized coaching for FSc students preparing for university entrance",
      features: ["Pre-Medical/Pre-Engineering", "University prep", "Concept building", "Problem solving"],
      image: "https://readdy.ai/api/search-image?query=FSc%20level%20advanced%20mathematics%20and%20science%20tutoring%20session%20with%20professional%20tutor%20elegant%20study%20room%20warm%20golden%20lighting%20luxury%20educational%20environment&width=400&height=300&seq=menu5&orientation=landscape"
    },
    {
      id: 6,
      name: "Commerce Premium",
      category: "level",
      price: "PKR 6,000",
      description: "Comprehensive commerce education for I.Com and B.Com students",
      features: ["Accounting mastery", "Business studies", "Economics focus", "Practical applications"],
      image: "https://readdy.ai/api/search-image?query=commerce%20and%20business%20studies%20tutoring%20session%20with%20charts%20graphs%20and%20business%20books%20elegant%20office%20setting%20warm%20golden%20lighting%20luxury%20educational%20environment&width=400&height=300&seq=menu6&orientation=landscape"
    },
    {
      id: 7,
      name: "Science Elite Program",
      category: "level",
      price: "PKR 6,800",
      description: "Advanced science subjects for B.Sc students with practical components",
      features: ["Physics mastery", "Chemistry labs", "Mathematics excellence", "Research methods"],
      image: "https://readdy.ai/api/search-image?query=science%20tutoring%20session%20with%20laboratory%20equipment%20books%20and%20scientific%20materials%20elegant%20study%20room%20warm%20golden%20lighting%20luxury%20educational%20setting%20academic%20excellence&width=400&height=300&seq=menu7&orientation=landscape"
    },
    {
      id: 8,
      name: "Online Luxury Learning",
      category: "online",
      price: "PKR 5,800",
      description: "Premium online tutoring with interactive tools and digital resources",
      features: ["Interactive whiteboards", "Recorded sessions", "Digital resources", "Flexible timing"],
      image: "https://readdy.ai/api/search-image?query=online%20learning%20setup%20with%20elegant%20computer%20screen%20showing%20virtual%20classroom%20luxury%20home%20office%20setting%20warm%20golden%20lighting%20modern%20educational%20technology&width=400&height=300&seq=menu8&orientation=landscape"
    },
    {
      id: 9,
      name: "Intensive Crash Course",
      category: "exam",
      price: "PKR 7,500",
      description: "Short-term intensive courses for quick exam preparation and concept revision",
      features: ["Rapid concept building", "Intensive practice", "Quick revision", "Last-minute prep"],
      image: "https://readdy.ai/api/search-image?query=intensive%20study%20session%20with%20multiple%20textbooks%20notes%20and%20practice%20papers%20elegant%20study%20room%20warm%20golden%20lighting%20focused%20academic%20atmosphere%20luxury%20educational%20setting&width=400&height=300&seq=menu9&orientation=landscape"
    }
  ];

  const categories = [
    { id: 'all', name: 'All Services' },
    { id: 'individual', name: 'Individual' },
    { id: 'group', name: 'Group' },
    { id: 'exam', name: 'Exam Prep' },
    { id: 'level', name: 'By Level' },
    { id: 'online', name: 'Online' }
  ];

  const filteredItems = activeFilter === 'all' 
    ? menuItems 
    : menuItems.filter(item => item.category === activeFilter);

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Fixed Transparent Navbar */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        scrollY > 100 ? 'bg-black/80 backdrop-blur-lg' : 'bg-transparent'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center">
                <i className="ri-graduation-cap-fill text-black text-xl"></i>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-yellow-400 font-serif">
                  New Punjab School
                </h1>
                <p className="text-sm text-yellow-300">& College</p>
              </div>
            </Link>
            <div className="hidden md:flex space-x-8">
              <Link href="/" className="text-white hover:text-yellow-400 font-medium transition-colors">Home</Link>
              <Link href="/story" className="text-white hover:text-yellow-400 font-medium transition-colors">Our Story</Link>
              <Link href="/menu" className="text-yellow-400 font-medium">Menu</Link>
              <Link href="/gallery" className="text-white hover:text-yellow-400 font-medium transition-colors">Gallery</Link>
              <Link href="/visit" className="text-white hover:text-yellow-400 font-medium transition-colors">Visit Us</Link>
              <Link href="/blog" className="text-white hover:text-yellow-400 font-medium transition-colors">Blog</Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center pt-20">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=elegant%20luxury%20educational%20menu%20showcase%20with%20golden%20lighting%20sophisticated%20academic%20materials%20books%20and%20learning%20tools%20warm%20atmospheric%20lighting%20premium%20educational%20services%20display&width=1920&height=1080&seq=menuhero&orientation=landscape')`
          }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/40"></div>
        
        <div className="relative z-10 text-center max-w-4xl mx-auto px-4">
          <h1 className="text-6xl md:text-8xl font-serif font-bold mb-8 text-yellow-400">
            Our Menu
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-12 font-light leading-relaxed">
            Discover our premium education services crafted for your academic success
          </p>
        </div>
      </section>

      {/* Filter Section */}
      <section className="py-12 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-4">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setActiveFilter(category.id)}
                className={`px-6 py-3 rounded-full font-semibold transition-all duration-300 cursor-pointer whitespace-nowrap ${
                  activeFilter === category.id
                    ? 'bg-gradient-to-r from-yellow-600 to-yellow-400 text-black'
                    : 'bg-yellow-900/20 text-yellow-400 border border-yellow-800/30 hover:border-yellow-600/50'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Menu Items */}
      <section className="py-20 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredItems.map((item) => (
              <div key={item.id} className="bg-gradient-to-br from-yellow-900/20 to-black rounded-xl overflow-hidden border border-yellow-800/30 hover:border-yellow-600/50 transition-all duration-300 group">
                <div className="h-48 overflow-hidden">
                  <img 
                    src={item.image} 
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                </div>
                
                <div className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-xl font-serif font-bold text-yellow-400">{item.name}</h3>
                    <div className="text-xl font-bold text-yellow-400">{item.price}</div>
                  </div>
                  
                  <p className="text-gray-300 mb-4 leading-relaxed">{item.description}</p>
                  
                  <ul className="space-y-2 mb-6">
                    {item.features.map((feature, index) => (
                      <li key={index} className="flex items-center text-gray-400">
                        <i className="ri-check-line text-yellow-400 mr-2"></i>
                        {feature}
                      </li>
                    ))}
                  </ul>
                  
                  <Link 
                    href={`/checkout/${item.id}`}
                    className="w-full bg-gradient-to-r from-yellow-600 to-yellow-400 text-black py-3 rounded-lg font-semibold hover:from-yellow-500 hover:to-yellow-300 transition-all duration-300 cursor-pointer whitespace-nowrap text-center block"
                  >
                    Order Now
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Payment Info */}
      <section className="py-16 bg-gray-900">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-gradient-to-br from-yellow-900/20 to-black rounded-xl p-8 border border-yellow-800/30">
            <div className="w-16 h-16 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="ri-cash-fill text-black text-2xl"></i>
            </div>
            <h3 className="text-2xl font-serif font-bold text-yellow-400 mb-4">Cash on Delivery Only</h3>
            <p className="text-gray-300 text-lg leading-relaxed">
              We believe in building trust through quality service. All orders are processed through WhatsApp 
              with convenient cash payment upon service delivery. No advance payments required.
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16 border-t border-yellow-800/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full flex items-center justify-center">
                  <i className="ri-graduation-cap-fill text-black text-lg"></i>
                </div>
                <div>
                  <h3 className="text-xl font-bold font-serif text-yellow-400">New Punjab School</h3>
                  <p className="text-sm text-yellow-300">& College</p>
                </div>
              </div>
              <p className="text-gray-400 leading-relaxed">
                Luxury education services where academic excellence meets sophisticated learning experiences.
              </p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4 text-yellow-400">Quick Links</h4>
              <ul className="space-y-2">
                <li><Link href="/" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Home</Link></li>
                <li><Link href="/story" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Our Story</Link></li>
                <li><Link href="/gallery" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Gallery</Link></li>
                <li><Link href="/blog" className="text-gray-400 hover:text-yellow-400 transition-colors cursor-pointer">Blog</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4 text-yellow-400">Education Levels</h4>
              <ul className="space-y-2">
                <li className="text-gray-400">Matric Excellence</li>
                <li className="text-gray-400">F.Sc Mastery</li>
                <li className="text-gray-400">I.Com Premium</li>
                <li className="text-gray-400">B.Com & B.Sc Elite</li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4 text-yellow-400">Contact</h4>
              <div className="space-y-3">
                <p className="text-gray-400 flex items-center">
                  <i className="ri-phone-fill mr-3 text-yellow-400"></i>
                  03010600547
                </p>
                <p className="text-gray-400 flex items-center">
                  <i className="ri-map-pin-fill mr-3 text-yellow-400"></i>
                  Cavalry Street 6, Lahore
                </p>
                <p className="text-gray-400 flex items-center">
                  <i className="ri-time-fill mr-3 text-yellow-400"></i>
                  Mon-Sat: 8AM-10PM
                </p>
              </div>
            </div>
          </div>
          
          <div className="border-t border-yellow-800/20 mt-12 pt-8 text-center">
            <p className="text-gray-400">
              © 2024 New Punjab School & College. Where futures begin.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}